		</div>

	</div><!-- END #wrapper -->
    <div id="footer">
        <a href="http://www.coddeeweb.com/">Diseñado y desarrollado por Coddee</a>
    </div>

    <script type="text/javascript" src="js/selectivizr.js"></script>
	<script type="text/javascript" src="js/jquery.colorbox-min.js"></script>
	<script type="text/javascript" src="js/script.js?v=1"></script>

	<!--[if lt IE 7 ]>
	<script type="text/javascript" src="js/dd_belatedpng.js?v=1"></script>
	<![endif]-->  
</body>
</html>