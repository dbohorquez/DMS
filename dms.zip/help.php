<?php $section = 'help'; ?>
<?php include('includes/header.php'); ?>
			<h2>Ayuda</h2>
            <p>Esta sección estará disponible próximamente.</p>
<?php include('includes/footer.php'); ?>