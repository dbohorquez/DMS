<?php $section = 'inicio'; ?>
<?php include('includes/header.php'); ?>
			<h2>Bienvenido</h2>
<?php include('includes/footer.php'); ?>